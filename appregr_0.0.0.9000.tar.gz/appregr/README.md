# appregr
[![DOI](https://zenodo.org/badge/195104416.svg)](https://zenodo.org/badge/latestdoi/195104416)

[![codecov](https://codecov.io/gh/brucebcampbell/appregr/branch/master/graph/badge.svg)](https://codecov.io/gh/brucebcampbell/appregr)

[![TravisCI](https://travis-ci.com/brucebcampbell/appregr.svg?branch=master)](https://travis-ci.com/brucebcampbell/appregr.svg?branch=master)

## Installation

You can install the released version of appregr from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("appregr")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
## basic example code
```

