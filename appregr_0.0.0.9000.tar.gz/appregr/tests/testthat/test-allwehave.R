context('functions')

test_that('We got numbers', {
    expect_equal(tested(5), 5)
})
