context("test-test-a")

test_that("multiplication works", {
  expect_equal(2 * 9, 18)
})
