library(testthat)
library(appregr)
#library(codecov.R)
test_check("appregr")

#test package
#test_check('codecov.R')
